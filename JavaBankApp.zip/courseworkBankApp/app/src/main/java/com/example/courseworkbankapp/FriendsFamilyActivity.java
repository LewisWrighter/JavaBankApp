package com.example.courseworkbankapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;

public class FriendsFamilyActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.friendsfamily);

        //find the image button
        ImageButton backButton = findViewById(R.id.backbutton);
        //set an onclick listener to switch to homepage
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //create a new intent to switch screens
                Intent intent = new Intent(FriendsFamilyActivity.this, HomePage.class);
                startActivity(intent);
                overridePendingTransition(R.transition.transition_right, R.transition.transition_left);
            }
        });
    }
}