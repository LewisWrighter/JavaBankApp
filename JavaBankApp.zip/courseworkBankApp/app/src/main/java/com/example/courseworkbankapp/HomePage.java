package com.example.courseworkbankapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.content.Intent;
import android.widget.ImageButton;

public class HomePage extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homepage);

        //find imagebutton forex
        ImageButton forex = findViewById(R.id.forex);

        //set an onclick listener
        forex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //set a new intent to switch screens
                Intent intent = new Intent(HomePage.this, CurrencyConverter.class);
                startActivity(intent);
                overridePendingTransition(R.transition.transition_right, R.transition.transition_left);
            }
        });

        //find imagebutton cookie
        ImageButton cookieButton = findViewById(R.id.cookie);

        //set an on click listener on the button to then switch activities
        cookieButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(HomePage.this, CookieClicker.class);
                startActivity(intent);
                overridePendingTransition(R.transition.transition_right, R.transition.transition_left);
            }
        });

        //find friendsfamily button
        ImageButton friendsFamilyButton = findViewById(R.id.friendsfamily);

//set an onclick listener for the button to switch activities
        friendsFamilyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //create an intent to open the FriendsFamilyActivity
                Intent intent = new Intent(HomePage.this, FriendsFamilyActivity.class);
                startActivity(intent);
                overridePendingTransition(R.transition.transition_right, R.transition.transition_left);
            }
        });
    }
}