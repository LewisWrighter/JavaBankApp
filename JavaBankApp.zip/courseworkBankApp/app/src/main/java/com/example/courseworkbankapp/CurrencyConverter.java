package com.example.courseworkbankapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class CurrencyConverter extends AppCompatActivity {

    //dollar to pound estimated exchange rate
    private double dollarRate = 1.28;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.foreignexchange); //set the view to the forex xml layout

        //find the buttons/objects
        EditText amount = findViewById(R.id.amount);
        TextView result = findViewById(R.id.result);
        Button convertButton = findViewById(R.id.convertButton);
        ImageButton homePageButton = findViewById(R.id.homepage);
        ImageButton cookiePageButton = findViewById(R.id.cookiepage);

        convertButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String amountText = amount.getText().toString();
                if (amountText.isEmpty() || !isNumeric(amountText)) {
                    return;
                }
                //parsing strings to double with the multiplier for dollars
                double amountInPounds = Double.parseDouble(amountText);
                double amountInDollars = amountInPounds * dollarRate;
                result.setText(String.format(Locale.getDefault(), "%.2f", amountInDollars));
            }
        });

        //set onclick listener for the home page button - then switch activities
        homePageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //create an intent to open the HomePage
                Intent intent = new Intent(CurrencyConverter.this, HomePage.class);
                startActivity(intent);
                overridePendingTransition(R.transition.transition_right, R.transition.transition_left);
            }
        });

        //set onclick listener for the cookie page button - then switch activities
        cookiePageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //create an intent to open the CookieClicker
                Intent intent = new Intent(CurrencyConverter.this, CookieClicker.class);
                startActivity(intent);
                overridePendingTransition(R.transition.transition_right, R.transition.transition_left);
            }
        });
    }

    //method to check if the string is numeric // fixes errors
    private boolean isNumeric(String strNum) {
        try {
            Double.parseDouble(strNum);
        } catch (NumberFormatException | NullPointerException nfe) {
            return false;
        }
        return true;
    }
}

