package com.example.courseworkbankapp;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.ImageButton;
import android.widget.TextView;

public class CookieClicker extends AppCompatActivity {

    //set an initial count to zero

    private int cookieCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cookieclicker);

        //declare buttons/objects

        ImageButton cookieButton = findViewById(R.id.cookie);
        ImageButton cookiePageButton = findViewById(R.id.cookiepage);
        ImageButton homePageButton = findViewById(R.id.homepage);
        ImageButton forexButton = findViewById(R.id.forex);
        final TextView cookieCountTextView = findViewById(R.id.cookieCount);

        //on click listener for the cookie button

        cookieButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cookieCount++; // Increment count
                cookieCountTextView.setText(String.valueOf(cookieCount)); // Update the textview to display the new count

                //animations

                ObjectAnimator scaleUpX = ObjectAnimator.ofFloat(cookieButton, "scaleX", 1.2f);
                ObjectAnimator scaleUpY = ObjectAnimator.ofFloat(cookieButton, "scaleY", 1.2f);
                scaleUpX.setDuration(50);
                scaleUpY.setDuration(50);

                //animations

                ObjectAnimator scaleDownX = ObjectAnimator.ofFloat(cookieButton, "scaleX", 1f);
                ObjectAnimator scaleDownY = ObjectAnimator.ofFloat(cookieButton, "scaleY", 1f);
                scaleDownX.setDuration(50);
                scaleDownY.setDuration(50);

                // expand

                scaleUpX.start();
                scaleUpY.start();

                // compress

                scaleDownX.setStartDelay(50);
                scaleDownY.setStartDelay(50);
                scaleDownX.start();
                scaleDownY.start();
            }
        });

        //on click listener for the cookie page button

        homePageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //new intent to open homepage with transition
                Intent intent = new Intent(CookieClicker.this, HomePage.class);
                startActivity(intent);
                overridePendingTransition(R.transition.transition_right, R.transition.transition_left);
            }
        });

        forexButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //new intent to open currency converter with transition
                Intent intent = new Intent(CookieClicker.this, CurrencyConverter.class);
                startActivity(intent);
                overridePendingTransition(R.transition.transition_right, R.transition.transition_left);
            }
        });
    }
}